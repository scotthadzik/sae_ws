Change history
==============

1.0.1 (2015-12-22)
------------------
* Removed Jim Rothrock from the maintainer list. Changed the version to 1.0.1.

1.0.0 (2015-08-28)
------------------
* Changed the version to 1.0.0.

0.9.1 (2014-04-30)
------------------
* Export architecture_independent flag in package.xml (`#3
  <https://github.com/jack-oquin/ackermann_msgs/issues/3>`_), thanks
  to Scott K Logan

0.9.0 (2013-03-17)
------------------

 * convert to catkin
 * release to Hydro

0.4.0 (2012-03-01)
------------------

 * initial release to both Fuerte and Electric following API review
 * later released with Groovy
