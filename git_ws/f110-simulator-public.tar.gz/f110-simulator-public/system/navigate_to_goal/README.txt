This is code in order to do navigation using teb_local_planner in the simulator. Because
it depends on code from other git repositories (using instructions from the
reference manual to set up the simulator), this repository will only contain the
/launch, /msg, and /scripts folders.  
